board = [' '] * 9

def show():
    print(f"\n{board[0]}|{board[1]}|{board[2]}\n-+-+-\n{board[3]}|{board[4]}|{board[5]}\n-+-+-\n{board[6]}|{board[7]}|{board[8]}\n")

def move(p):
    pos = int(input(f"Player {p}, choose (1–9): ")) - 1
    if board[pos] == ' ':
        board[pos] = p
    else:
        print("Taken! Try again."); move(p)

for turn in range(9):
    show()
    move('X' if turn % 2 == 0 else 'O')
    if any(board[a]==board[b]==board[c]!=' ' for a,b,c in [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]):
        show(); print("🎉 Winner!"); break
