students = {}

def add_student():
    name = input("Name: ")
    marks = list(map(int, input("Marks (comma separated): ").split(',')))
    students[name] = sum(marks)/len(marks)

def show_students():
    for s, avg in students.items():
        print(f"{s}: {avg:.2f}%")

while True:
    c = input("1.Add  2.View  3.Exit: ")
    if c == '1': add_student()
    elif c == '2': show_students()
    else: break
