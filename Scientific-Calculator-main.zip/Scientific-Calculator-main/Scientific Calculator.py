import math

print("Functions: sqrt, sin, cos, tan, log")
exp = input("Enter expression (e.g., sin(30), sqrt(25)): ")

try:
    result = eval("math." + exp)
    print("Result:", result)
except Exception as e:
    print("Error:", e)
