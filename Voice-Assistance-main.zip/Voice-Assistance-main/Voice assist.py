import speech_recognition as sr
import pyttsx3
import datetime

engine = pyttsx3.init()
def speak(text):
    engine.say(text)
    engine.runAndWait()

r = sr.Recognizer()
with sr.Microphone() as source:
    print("Listening...")
    audio = r.listen(source)
try:
    query = r.recognize_google(audio)
    print("You said:", query)
    if "time" in query:
        speak(datetime.datetime.now().strftime("%H:%M:%S"))
    else:
        speak("I heard you say " + query)
except:
    speak("Sorry, I didn’t catch that.")
