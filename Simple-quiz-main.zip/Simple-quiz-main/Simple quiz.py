score = 0
questions = {
    "Capital of India? ": "Delhi",
    "2 + 5 = ? ": "7",
    "Color of sky? ": "Blue"
}

for q, a in questions.items():
    ans = input(q).strip().lower()
    if ans == a.lower():
        print("Correct!")
        score += 1
    else:
        print("Wrong!")
print("Final Score:", score, "/", len(questions))
