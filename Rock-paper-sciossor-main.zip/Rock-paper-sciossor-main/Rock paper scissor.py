# rps_simple.py
import random

choices = ['rock', 'paper', 'scissors']

user = input("Choose rock, paper, or scissors: ").strip().lower()
if user not in choices:
    print("Invalid choice. Try again.")
else:
    comp = random.choice(choices)
    print(f"Computer chose: {comp}")

    if user == comp:
        print("It's a tie!")
    elif (user == 'rock' and comp == 'scissors') or \
         (user == 'paper' and comp == 'rock') or \
         (user == 'scissors' and comp == 'paper'):
        print("You win! 🎉")
    else:
        print("You lose. 😢")
