tasks = []

while True:
    print("\n1. Add  2. View  3. Remove  4. Exit")
    ch = input("Choose: ")
    if ch == '1':
        tasks.append(input("Enter task: "))
    elif ch == '2':
        for i, t in enumerate(tasks, 1): print(i, t)
    elif ch == '3':
        n = int(input("Task number: ")); tasks.pop(n-1)
    elif ch == '4':
        print("Goodbye!"); break
    else:
        print("Invalid choice!")
