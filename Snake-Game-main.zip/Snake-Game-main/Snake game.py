import turtle, time, random

delay = 0.1
score = 0
snake = [turtle.Turtle(shape="square")]

food = turtle.Turtle()
food.shape("circle")
food.color("red")
food.penup()
food.goto(0,100)

while True:
    snake[0].forward(20)
    if snake[0].distance(food) < 15:
        food.goto(random.randint(-200,200), random.randint(-200,200))
        s = turtle.Turtle(shape="square")
        s.penup()
        snake.append(s)
    time.sleep(delay)
