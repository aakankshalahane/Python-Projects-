# 1 pip install qrcode[pil]
import qrcode

data = input("Enter text or URL: ")
img = qrcode.make(data)
img.save("qrcode.png")
print("QR code saved as qrcode.png")
