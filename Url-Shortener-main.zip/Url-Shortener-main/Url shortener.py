# 1 pip install pyshorteners

import pyshorteners

link = input("Enter URL: ")
short = pyshorteners.Shortener()
print("Shortened URL:", short.tinyurl.short(link))
